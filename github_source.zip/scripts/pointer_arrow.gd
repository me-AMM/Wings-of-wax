# AI-assisted code (Claude Code), reviewed by the team, NASA Space Apps Cairo 2026
extends Node2D
# Pointer arrow: a small yellow triangle with a 1 px dark outline, drawn in code (no art).
# The Mission scene moves it around the player (about 24 px away) and rotates it toward the target.
func _ready() -> void:
	z_index = 300

func _draw() -> void:
	var pts := PackedVector2Array([Vector2(8, 0), Vector2(-5, -6), Vector2(-5, 6)])
	draw_colored_polygon(pts, UIStyle.ACCENT)
	var outline := PackedVector2Array(pts)
	outline.append(pts[0])
	draw_polyline(outline, UIStyle.PANEL_DARK, 1.0)
